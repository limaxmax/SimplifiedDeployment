-- MySQL dump 10.13  Distrib 5.6.28, for Linux (x86_64)
--
-- Host: localhost    Database: ftp_db
-- ------------------------------------------------------
-- Server version	5.6.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_mq_insulation`
--

DROP TABLE IF EXISTS `t_mq_insulation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_mq_insulation` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `creation_date` datetime NOT NULL,
  `Stamp` bigint(11) DEFAULT NULL,
  `Value` varchar(45) DEFAULT NULL,
  `DeviceNo` varchar(45) DEFAULT NULL,
  `TypeNo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `creation_date_indx` (`creation_date`),
  KEY `insulation_index` (`Stamp`,`DeviceNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_mq_insulation`
--

LOCK TABLES `t_mq_insulation` WRITE;
/*!40000 ALTER TABLE `t_mq_insulation` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_mq_insulation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_mq_leakage`
--

DROP TABLE IF EXISTS `t_mq_leakage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_mq_leakage` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `creation_date` datetime NOT NULL,
  `Stamp` bigint(11) DEFAULT NULL,
  `Value` varchar(45) DEFAULT NULL,
  `DeviceNo` varchar(45) DEFAULT NULL,
  `TypeNo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `creation_date_indx` (`creation_date`),
  KEY `leakage_index` (`Stamp`,`DeviceNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_mq_leakage`
--

LOCK TABLES `t_mq_leakage` WRITE;
/*!40000 ALTER TABLE `t_mq_leakage` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_mq_leakage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_mq_mssanalog`
--

DROP TABLE IF EXISTS `t_mq_mssanalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_mq_mssanalog` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `creation_date` datetime NOT NULL,
  `Stamp` bigint(11) DEFAULT NULL,
  `Value` varchar(45) DEFAULT NULL,
  `DeviceNo` varchar(45) DEFAULT NULL,
  `TypeNo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `creation_date_indx` (`creation_date`),
  KEY `mssanalog_index` (`Stamp`,`DeviceNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_mq_mssanalog`
--

LOCK TABLES `t_mq_mssanalog` WRITE;
/*!40000 ALTER TABLE `t_mq_mssanalog` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_mq_mssanalog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_mq_mssvoatage`
--

DROP TABLE IF EXISTS `t_mq_mssvoatage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_mq_mssvoatage` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `creation_date` datetime NOT NULL,
  `Stamp` bigint(11) DEFAULT NULL,
  `Value` varchar(45) DEFAULT NULL,
  `DeviceNo` varchar(45) DEFAULT NULL,
  `TypeNo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `creation_date_indx` (`creation_date`),
  KEY `mssvoatage_index` (`Stamp`,`DeviceNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_mq_mssvoatage`
--

LOCK TABLES `t_mq_mssvoatage` WRITE;
/*!40000 ALTER TABLE `t_mq_mssvoatage` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_mq_mssvoatage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_mq_outelectricity`
--

DROP TABLE IF EXISTS `t_mq_outelectricity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_mq_outelectricity` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `creation_date` datetime NOT NULL,
  `Stamp` bigint(11) DEFAULT NULL,
  `Value` varchar(45) DEFAULT NULL,
  `DeviceNo` varchar(45) DEFAULT NULL,
  `TypeNo` varchar(45) DEFAULT NULL,
  `SubLineNo` varchar(45) DEFAULT NULL,
  `EleType` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `creation_date_indx` (`creation_date`),
  KEY `mssanalog_index` (`Stamp`,`DeviceNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_mq_outelectricity`
--

LOCK TABLES `t_mq_outelectricity` WRITE;
/*!40000 ALTER TABLE `t_mq_outelectricity` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_mq_outelectricity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_mq_powerquantity`
--

DROP TABLE IF EXISTS `t_mq_powerquantity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_mq_powerquantity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `creation_date` datetime NOT NULL,
  `Stamp` bigint(11) DEFAULT NULL,
  `value` varchar(45) DEFAULT NULL,
  `DeviceNO` varchar(45) DEFAULT NULL,
  `flag` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `creation_date_indx` (`creation_date`),
  KEY `powerQuantity_index` (`Stamp`),
  KEY `stamp_deviceno_flag` (`Stamp`,`DeviceNO`,`flag`)
) ENGINE=InnoDB AUTO_INCREMENT=16646746 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_mq_powerquantity`
--

LOCK TABLES `t_mq_powerquantity` WRITE;
/*!40000 ALTER TABLE `t_mq_powerquantity` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_mq_powerquantity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_mq_station`
--

DROP TABLE IF EXISTS `t_mq_station`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_mq_station` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `creation_date` datetime NOT NULL,
  `Stamp` bigint(11) DEFAULT NULL,
  `msg` mediumtext,
  PRIMARY KEY (`id`),
  KEY `creation_date_indx` (`creation_date`),
  KEY `station_index` (`Stamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_mq_station`
--

LOCK TABLES `t_mq_station` WRITE;
/*!40000 ALTER TABLE `t_mq_station` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_mq_station` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_mq_switchcurve`
--

DROP TABLE IF EXISTS `t_mq_switchcurve`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_mq_switchcurve` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `creation_date` datetime NOT NULL,
  `Time` bigint(11) DEFAULT NULL,
  `DeviceNo` varchar(45) DEFAULT NULL,
  `MachineID` varchar(45) DEFAULT NULL,
  `ChangeDir` varchar(45) DEFAULT NULL,
  `SwitchCnt` varchar(45) DEFAULT NULL,
  `CurveInterval` varchar(45) DEFAULT NULL,
  `Curve` text,
  PRIMARY KEY (`id`),
  KEY `creation_date_indx` (`creation_date`),
  KEY `switchCurve_index` (`Time`,`DeviceNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_mq_switchcurve`
--

LOCK TABLES `t_mq_switchcurve` WRITE;
/*!40000 ALTER TABLE `t_mq_switchcurve` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_mq_switchcurve` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_mq_switchcurvedetail`
--

DROP TABLE IF EXISTS `t_mq_switchcurvedetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_mq_switchcurvedetail` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `DeviceNo` varchar(50) NOT NULL,
  `time` bigint(20) DEFAULT NULL,
  `CurveInterval` int(11) DEFAULT NULL,
  `Stamp` bigint(20) DEFAULT NULL,
  `CurveType` int(11) DEFAULT NULL,
  `SubCurveType` int(11) DEFAULT NULL,
  `Curve` double DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_mq_switchcurvedetail`
--

LOCK TABLES `t_mq_switchcurvedetail` WRITE;
/*!40000 ALTER TABLE `t_mq_switchcurvedetail` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_mq_switchcurvedetail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_mq_switchgapanalog`
--

DROP TABLE IF EXISTS `t_mq_switchgapanalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_mq_switchgapanalog` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `creation_date` datetime NOT NULL,
  `Time` bigint(11) DEFAULT NULL,
  `DeviceNo` varchar(45) DEFAULT NULL,
  `MachineID` varchar(45) DEFAULT NULL,
  `ChangeDir` varchar(45) DEFAULT NULL,
  `MoveFlat` varchar(45) DEFAULT NULL,
  `MoveValue` varchar(45) DEFAULT NULL,
  `GapValue` varchar(45) DEFAULT NULL,
  `StandarValue` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `creation_date_indx` (`creation_date`),
  KEY `switchAnalog_index` (`Time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_mq_switchgapanalog`
--

LOCK TABLES `t_mq_switchgapanalog` WRITE;
/*!40000 ALTER TABLE `t_mq_switchgapanalog` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_mq_switchgapanalog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_mq_switchgapotheranalog`
--

DROP TABLE IF EXISTS `t_mq_switchgapotheranalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_mq_switchgapotheranalog` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `creation_date` datetime NOT NULL,
  `Stamp` bigint(11) DEFAULT NULL,
  `Value` varchar(45) DEFAULT NULL,
  `DeviceNo` varchar(45) DEFAULT NULL,
  `TypeNo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `creation_date_indx` (`creation_date`),
  KEY `otherAnalog_index` (`Stamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_mq_switchgapotheranalog`
--

LOCK TABLES `t_mq_switchgapotheranalog` WRITE;
/*!40000 ALTER TABLE `t_mq_switchgapotheranalog` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_mq_switchgapotheranalog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_mq_switchvoltage`
--

DROP TABLE IF EXISTS `t_mq_switchvoltage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_mq_switchvoltage` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `creation_date` datetime NOT NULL,
  `Stamp` bigint(11) DEFAULT NULL,
  `Value` varchar(45) DEFAULT NULL,
  `DeviceNo` varchar(45) DEFAULT NULL,
  `TypeNo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `creation_date_indx` (`creation_date`),
  KEY `mssanalog_index` (`Stamp`,`DeviceNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_mq_switchvoltage`
--

LOCK TABLES `t_mq_switchvoltage` WRITE;
/*!40000 ALTER TABLE `t_mq_switchvoltage` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_mq_switchvoltage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_mq_trainruninfo`
--

DROP TABLE IF EXISTS `t_mq_trainruninfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_mq_trainruninfo` (
  `id` bigint(32) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `DeviceNo` varchar(32) DEFAULT NULL COMMENT '设备编号（预留），null',
  `vobcIndex` varchar(32) DEFAULT NULL COMMENT 'Vobc唯一标识',
  `timeTick` int(32) DEFAULT NULL COMMENT '时间戳',
  `tripNumber` varchar(32) DEFAULT NULL COMMENT '车次号',
  `serviceNumber` varchar(32) DEFAULT NULL COMMENT '表号',
  `destinationCode` int(32) DEFAULT NULL COMMENT '目的地号',
  `groupNumber` varchar(32) DEFAULT NULL COMMENT '列车车组号',
  `crewNumber` varchar(32) DEFAULT NULL COMMENT '驾驶员号',
  `headDirection` int(16) DEFAULT NULL COMMENT '列车期望运行的方向,VOBC确认列车车头方向与列车期望运行方向一致',
  `runStatus` int(16) DEFAULT NULL COMMENT '列车运行方向状态（0未知,1=前行:与列车期望运行方向一致,2=退行:与列车期望运行方向相反）',
  `speed` int(16) DEFAULT NULL COMMENT '列车速度，单位为公里/小时',
  `driveMode` int(16) DEFAULT NULL COMMENT '列车的驾驶模式(0=UNKNOWN,1=RM,2=CM,3=AM,4=FAO)',
  `doorStatus` int(16) DEFAULT NULL COMMENT '列车车门的状态（0=未知1=关闭2=开门)',
  `holdStatus` int(16) DEFAULT NULL COMMENT '列车的扣车状态（0=未知,1=列车扣车,2=没有扣车)',
  `stoppedStatus` int(16) DEFAULT NULL COMMENT '列车在停车区域的停稳信息（0=未知,1=列车停稳,2=列车没有停稳)',
  `stoppedArea` int(16) DEFAULT NULL COMMENT '列车停稳所在的停车区域编号',
  `holdCtrl` int(16) DEFAULT NULL COMMENT 'ATS期望VOBC响应扣车的停车区域编号',
  `departAreaCtrl` int(16) DEFAULT NULL COMMENT '列车出发的停车区域编号',
  `arriveAreaCtrl` int(16) DEFAULT NULL COMMENT '列车将要到达的停车区域编号',
  `platformDwellTime` int(16) DEFAULT NULL COMMENT '列车在当前停车区域的停站剩余时间值，单位秒',
  `nextRuntimeLevel` int(16) DEFAULT NULL COMMENT '列车发车时下一区间的运行等级',
  `insertDateTime` bigint(20) DEFAULT NULL COMMENT '创建时间，三天后删除',
  `choiceMode` int(16) DEFAULT NULL,
  `ctrlLevel` int(16) DEFAULT NULL,
  `ebiSpeed` int(16) DEFAULT NULL,
  `stationFireCmdAck` int(16) DEFAULT NULL,
  `vobcWorkCondition` int(16) DEFAULT NULL,
  `routeDir` int(16) DEFAULT NULL,
  `famAuthorCmdAck` int(16) DEFAULT NULL,
  `departReq` int(16) DEFAULT NULL,
  `departReson` int(16) DEFAULT NULL,
  `camReq` int(16) DEFAULT NULL,
  `resonToCam` int(16) DEFAULT NULL,
  `clearStatus` int(16) DEFAULT NULL,
  `isOverPoint` int(16) DEFAULT NULL,
  `stoppedPrecision` int(16) DEFAULT NULL,
  `joggerStatus` int(16) DEFAULT NULL,
  `snowStatus` int(16) DEFAULT NULL,
  `trainFireAlarm` int(16) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_mq_trainruninfo`
--

LOCK TABLES `t_mq_trainruninfo` WRITE;
/*!40000 ALTER TABLE `t_mq_trainruninfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_mq_trainruninfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_mq_vobcspeed`
--

DROP TABLE IF EXISTS `t_mq_vobcspeed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_mq_vobcspeed` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `creation_date` datetime NOT NULL,
  `stamp` bigint(11) DEFAULT NULL,
  `DeviceNo` varchar(45) DEFAULT NULL,
  `Index` varchar(45) DEFAULT NULL,
  `TrainSpeed` varchar(45) DEFAULT NULL,
  `EbiSpeed` varchar(45) DEFAULT NULL,
  `BrakeProportion` varchar(45) DEFAULT NULL,
  `AtoTms` varchar(45) DEFAULT NULL,
  `AtoStatus` varchar(45) DEFAULT NULL,
  `Aractive` varchar(45) DEFAULT NULL,
  `Brake` varchar(45) DEFAULT NULL,
  `KeepBrake` varchar(45) DEFAULT NULL,
  `LeftOpen` varchar(45) DEFAULT NULL,
  `LeftClose` varchar(45) DEFAULT NULL,
  `RightOpen` varchar(45) DEFAULT NULL,
  `RightClose` varchar(45) DEFAULT NULL,
  `Light` varchar(45) DEFAULT NULL,
  `AtoAnlog` varchar(45) DEFAULT NULL,
  `TargetSpeed` varchar(45) DEFAULT NULL,
  `ActualDeceleration` varchar(45) DEFAULT NULL,
  `TargetDeceleration` varchar(45) DEFAULT NULL,
  `ODO1Speed` varchar(45) DEFAULT NULL,
  `ODO2Speed` varchar(45) DEFAULT NULL,
  `RdrSpeed` varchar(45) DEFAULT NULL,
  `ODO1Error` varchar(45) DEFAULT NULL,
  `ODO2Error` varchar(45) DEFAULT NULL,
  `RdrError` varchar(45) DEFAULT NULL,
  `VobcHead` varchar(45) DEFAULT NULL,
  `HeadRdrRatio` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `creation_date_indx` (`creation_date`),
  KEY `vobc_index` (`stamp`,`Index`,`VobcHead`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_mq_vobcspeed`
--

LOCK TABLES `t_mq_vobcspeed` WRITE;
/*!40000 ALTER TABLE `t_mq_vobcspeed` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_mq_vobcspeed` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-25 11:52:53
